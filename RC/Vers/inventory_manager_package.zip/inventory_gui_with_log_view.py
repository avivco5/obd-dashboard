# Replace this with the full GUI code provided earlier.
print('Inventory Manager GUI loaded.')