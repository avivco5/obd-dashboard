import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.withdraw()

messagebox.showerror("שגיאה", "מק\"ט לא קיים במלאי")
